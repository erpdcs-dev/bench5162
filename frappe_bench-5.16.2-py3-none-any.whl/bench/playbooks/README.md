# Deploying a, developer/production-ready ERPNext website with Ansible

## Supported Platforms
	- Debian 8, 9
	- Ubuntu 14.04, 16.04
	- CentOS 7

## Notes for maintainers
	- For MariaDB playbooks refer https://github.com/PCextreme/ansible-role-mariadb 
	- Any changes made in relation to a role should be dont inside the role and not outside it
